<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WhStock extends Model
{
    use HasFactory;
    protected $table = 'wh_stock';
}

@extends('layouts.app')

@section('container')
    Aqui va el detalle
@endsection
@extends('layouts.app')

@section('container')
    aqui va el deta
@endsection